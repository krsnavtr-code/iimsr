<?php

include('header/head.php');
if (isset($_SESSION['enrolment'])){
?>

<!DOCTYPE html >
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8">
    <meta name="robots" content="Index, Follow" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>VBIMT Course Books</title>
    <link rel="stylesheet" type="text/css" href="css/csss.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script src="js/vbimtlandingpage.js"></script>

</head>
<body>
<div class="container vbimt-books">
    <div class="row" id="top-bar">
	    <div class="col-sm-8 col-md-8 col-lg-8 col-xs-8" id="top-bar">
			<a href="http://vbimt.org.in/"><img src="logo.png" alt="DZone" class="floatleft AdminPanelLogo" /></a>
		</div>	
		<div class="col-sm-4 col-md-4 col-lg-4 col-xs-4">
            <div class="topmeenu" style="">
                <a href="logout.php"><button type="button" class="btn btn-danger AdminLogoutBu">Logout</button></a>
        	</div>
            <div class="topm"></div>
	    </div>
	</div>
    <?php include('header/header.php'); ?>

    <h3>Books Record</h3>
    <div style="margin: 30px 0px 30px 0px;overflow-x:auto; margin-bottom: 50px;">
        <table class="table table-hover no-more-tables">
            <tr>
                <th style="width:150px;">Enrollment No</th>
                <th>Course</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Mobile No</th>
            </tr>
            <?php
                $enrol = $_SESSION['enrolment'];
                $query = mysqli_query($con, "SELECT * FROM `books_send` where `enrolment` = '$enrol'");
                $row = mysqli_fetch_array($query);
            ?>
            <tr>
                <td><?php echo $row['enrolment'];?></td>
                <td><?php echo $row['course_name'];?></td>
                <td><?php echo $row['name'];?></td>
                <td><?php echo $row['email'];?></td>
                <td><?php echo $row['mobile_no'];?></td>
            </tr>
        </table>
        <div class="row">
            <h3 style="margin-left:15px;">Books</h3>
            <div class="col-sm-8 col-md-8 col-lg-8 col-xs-12">
                <?php $pdfdata = explode('::',$row['pdf_upload']) ?>
                <?php foreach ($pdfdata as $pdf){ ?>
                    <a href="uploaded/<?php echo $pdf;?>"><?php echo $pdf;?></a><br>
                <?php } ?>
            </div>
        </div>
    </div>
    <div class="row">
		<div class="col-sm-12 col-md-12 col-lg-12 col-xs-12">
            <p class="Kindlydeposit">Kindly deposit your fees in VIDYA BHARATI INSTITUTE MANAGEMENT & TECHNOLOGY account only, any fee deposited in any other account EXCEPT VBIMT will not be considered.<span style="color:#160fe8"> For any issue related to fees or examination please call @ 9266585858</span></p>
        </div>
    </div>
    <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xs-12">
            	<div id="footer">
            		© VBIMT Advance System Integration.
            		<div class="footermenu"><a href="https://www.vbimt.org.in/">Home</a> | <a href="https://www.vbimt.org.in/privacy-policy">Privacy policy</a> | <a href="https://www.vbimt.org.in/contact">Contact us</a></div>
            	</div>
                <?php //include('footer/footer.php'); ?>
            </div>
        </div>
    <?php// include('footer/footer.php'); ?>
<?php
}else {
	 header("location: login.php");
	}
	?>
</div>
<style>
    .Kindlydeposit{
        color:red; 
        font-weight:bold;
        font-size:14px;
        text-align:justify;
    }
   .AdminPanelLogo {
        width: 200px;
        height: auto;
    }
    .AdminLogoutBu {
        border-radius: 0px !important;
        padding: 7px 13px 7px 13px !important;
    }
    .topmeenu {
        border-radius: 0px;
        float: right;
        margin: 51px 2px -83px 0px;
    }
    @media(max-width:992px){
        .Kindlydeposit{
            color:red !important;
            font-weight:bold !important;
            font-size:10px !important;
        }
        .topmeenu {
            border-radius: 0px !important;
            float: right !important;
            margin: 0px 0px -70px 0px !important;
        } 
    }
   </style>
</body>
</html>
