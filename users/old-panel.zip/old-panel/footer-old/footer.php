<div class="row">
	<div class="col-sm-12 col-md-12 col-lg-12 col-xs-12">
        <p class="Kindlydeposit">Kindly deposit your fees in Imperial Institute of Management Science & Research account only, any fee deposited in any other account EXCEPT IIMSR will not be considered.<span style="color:#160fe8"> For any issue related to fees or examination please call @ +91 8595113493</span></p>
    </div>
</div>
<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12 col-xs-12">
    	<div id="footer">
    		<span class="Advancevv">© IIMSR Advance System Integration.</span>
    		<div class="footermenu"><a href="https://iimsr.net.in/">Home</a> | <a href="https://iimsr.net.in/privacy-policy">Privacy policy</a> | <a href="https://iimsr.net.in/contact">Contact us</a></div>
    	</div>
    </div>
</div>