<?php
include('header/head.php');
?>
<!DOCTYPE html >
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">	
	<title>VBIMT Institute</title>
	<link rel="stylesheet" type="text/css" href="css/csss.css" />	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script src="js/vbimtlandingpage.js"></script>
	
<script type="text/javascript">
    $(function () {
        $("#btnGet").click(function () {
            var selectedText = $("#ddlFruits").find("option:selected").text();
            var selectedValue = $("#ddlFruits").val();
            alert("Selected Text: " + selectedText + " Value: " + selectedValue);
        });
    });
</script>
</head>
<body>
	<div class="container">
		<div id="top-bar">
			<a href="http://vbimt.org.in/"><img src="logo.png" alt="DZone" class="floatleft" /></a>
			   <div class="topmeenu" style="">
					<!--<a href="#" class="first">User Name</a>
					<a href="#">Submit New</a>
					<a href="logout.php">Logout</a>-->
					<!--<a href="#"><button type="button" class="btn btn-Primary">User Name</button></a>
					<a href="#"><button type="button" class="btn btn-success">Submit New</button></a>-->
					<a href="logout.php"><button type="button" class="btn btn-danger">Logout</button></a>
					
				</div>
			 <div class="topm">
				<!--<form id="main-search"action="index.php " method="post">
					<label for="search-field" id="search-field-label">Search</label>
					<input type="text" tabindex="1" maxlength="255" id="search-field"/>
					<input type="image" alt="Search" value="Search" style="" src="images/search.png" id="search-button"/>-->  
				</form>
			</div>
		</div>
				
              
              <?php include('header/header.php'); ?>
              
                <div id="feature-content">
					<div id="result" class="">
						<div id="feature">
							<div style=" margin-bottom: 20px; ">
							<form class="form-contentset" name="f1" action="" method="post">
								<h3>Select :
									<!--<select class="-formcontrol" id="selectBox" name="seme" onchange="changeFunc();">-->
									
								<select class="selectorop" id="selectBox" name="semester" required>
										<option value="" disable selected>--Select Semester--</option>
										<?php
										
										    $query=mysqli_query($con,"select `semester` from `semester_subject` WHERE `course` = '$course'");
										    $array = array();
										    while($row = mysqli_fetch_array($query)){
										        $string = str_replace(' ','',strtolower($row['semester']));
										        if(!in_array($string,$array)){
										         $array[] = $string; 
										        }
										    }
										    foreach($array as $semester)
											{ 
											    
										?>
											<option value="<?php echo $semester; ?>"><?php echo $semester; ?></option>
										<?php } ?>
								</select>
									<input type="submit" name="submit" class="btn btn-warning btnclass">
								</h3>
								</form>	
								<!--<div class="row">
									<div class="col-md-12">
										<center><h4>Vidya Bharati Institute of Management & Technology</h4></center>
									</div>
								</div>-->
							<?php
								if(isset($_POST['submit'])){
								$sem = $_POST['semester'];
								$sem = str_replace(' ','',$sem);
								$sem = strtolower($sem);
								
								$query = "SELECT r.name,r.dob,r.status,r.fathers_name,r.course,r.specilization, m.serial_no,m.year,r.courseslug,m.total_max_marks,m.semester,m.total_min_marks,m.certificate_grade,m.certificate_month,m.total_obt_marks,m.certificated_deliver_date,m.stu_result FROM `register_here` AS r INNER JOIN `students_marks` AS m ON r.enrolment = m.enrolment WHERE m.enrolment = '$enro' AND m.semester = '$sem'";
								  
									$query=mysqli_query($con,$query);
									$num=mysqli_num_rows($query);
									
								if($num>0){
										$std = mysqli_fetch_array($query);
										$newsem =  str_replace(' ','',$sem);
										$newcourse = $newsem;
										$newsemester = strtolower($newsem);
										$query=mysqli_query($con,"SELECT * From `semester_subject` WHERE `enrolment` = '$enro' AND `semester` = '$newsemester'");
										$mca = mysqli_fetch_array($query);
										
										$semmark =strtolower($newsem);
										$marksquery=mysqli_query($con,"SELECT * From `students_marks` WHERE `enrolment` = '$enro' AND `semester` = '$semmark' AND `course` = '$course'");
										$rowmarks = mysqli_fetch_array($marksquery);
								
										
							?>
							
							<?php if($std['status']==1){ 
							die($std['status']);
							?>
							
                            <table align="center" style="width: 1000px; border: 2px solid rgb(0, 0, 0); padding:0px">
                                <tbody>
									<tr>
                                        <td align="center">
                                            <h4>
                                                Vidya Bharati Institute of Management &amp; Technology
                                            </h4>
                                        </td>
                                    </tr>
                                    <tr>
										<td valign="top">
											<table>
												<tbody>
													<tr>
														<td>
															<table align="center" style="">
																<tbody>
																	<tr>
																		<td style="padding:5px;"><b>Serial No. : </b>
																			<span id=""><?php echo $std['serial_no']; ?></span>
																		</td>
																		<td style="padding:5px;" align="center">
																			<b>Enrollment No. : </b>
																			<span id=""><?php echo $enro; ?></span>
																		</td>
																	</tr>
																	<tr>
																		<td style="padding:5px;" style=""><b>Name : </b>
																			<span id=""><?php echo $std['name']; ?></span>
																		</td style="padding:5px;" >
																		<td align="center"><b>Semester/Year : </b><span id="">
																		    <?php if($semmark=="semester1"){ ?>
																		     First
																		    <?php } ?>
																		    <?php if($semmark=="semester2"){ ?>
																		     Second
																		    <?php } ?>
																		    <?php if($semmark=="semester3"){ ?>
																		     Third
																		    <?php } ?>
																		    <?php if($semmark=="semester4"){ ?>
																		     Fourth
																		    <?php } ?>
																		    <?php if($semmark=="semester5"){ ?>
																		     Fifth
																		    <?php } ?>
																		    <?php if($semmark=="semester6"){ ?>
																		     Sixth
																		    <?php } ?>
																		    <?php if($semmark=="semester7"){ ?>
																		     Seventh
																		    <?php } ?>
																		    <?php if($semmark=="semester8"){ ?>
																		     Eighth
																		    <?php } ?>
																		    </span></td>
																	</tr>
																	<tr>
																		<td style="padding:5px;"><b>Father's Name : </b><span>
																			<span id=""><?php echo $std['fathers_name'];?></span></span>
																		</td>
																		<td align="center"><b>DOB : </b><span><span id=""><?php echo $std['dob'];?></span></span></td>
																	</tr>
																</tbody>
															</table>
															<table style="">
																<tr>
																	<td style="padding:5px;" align="center">
																		<span><b>
																			<span id="" style="font-size:15px;"><?php echo $std['course'];?></span></b>&nbsp;&nbsp;
																			<span id=""><strong>Branch:</strong> <?php echo $std['specilization'];?></span>
																		</span>
																	</td>
																</tr>
															</table>
														</td>
													</tr>
												</tbody>
											</table>
											<tr>
												<td>
												<?php
													$enro = $_SESSION['login'];
													$query12 = mysqli_query($con, "select * from `course` where `semester` = '$semmark' AND `course` = '$course'");
													$row12 = mysqli_fetch_array($query12); 
												    $totalmxm =  $row12['max_mark'];
													$totalmnm =  $row12['min_mark'];
													$query = mysqli_query($con, "select * from `students_marks` where `enrolment` = '$enro' AND `semester` = '$semmark'");
													$row = mysqli_fetch_array($query); 
												
													$totalmaxm =  $row['total_max_marks'];
													$totalminm =  $row['total_min_marks'];
													$totalobt =  $row['total_obt_marks'];
													$totamax = 0;
													$totalmin=0;
													$totalobtcal =0;
												
												?>
													<table style="">
														<tbody>
															<tr>
																<td style="padding:5px 60px"><b>Subject</b></td>
																<td align="center"><b>Max. Marks </b></td>
																<td align="center"><b>Min. Marks</b></td>
																<td align="center"><b>Marks Obt.</b></td>
																<td align="center"><b>Result</b></td>
																<td align="center"><b>Passing Month Year</b></td>
															</tr>
														<?php if(!empty($mca['subject1'])){
														$totamax += 100;
														$totalmin +=40;
														$totalobtcal +=$rowmarks['subject1'];
														?>
															<tr>
																<td style="padding: 5px 60px">
																	<span id=""><?php echo $mca['subject1']; ?></span></td>
																<td align="center">
																	<span id="">100</span></td>
																<td align="center">
																	<span id="">40</span></td>
																<td align="center">
																	<span id=""><?php echo $rowmarks['subject1']; ?></span></td>
															</tr>
															<?php } ?>
															
															<?php if(!empty($mca['subject2'])){
    														$totamax += 100;
    														$totalmin +=40;
    														$totalobtcal +=$rowmarks['subject2'];
    														?>
															<tr>
																<td style="padding: 5px 60px">
																	<span id=""><?php echo $mca['subject2']; ?></span></td>
																<td align="center">
																	<span id="">100</span></td>
																<td align="center">
																	<span id="">40</span></td>
																<td align="center">
																	<span id=""><?php echo $rowmarks['subject2']; ?></span></td>
																<td align="center">
																	<span id=""><?php echo $rowmarks['stu_result']; ?></span></td>
																<td align="center">
																	<span id=""><?php echo $row['pass_month_year']; ?></span></td>
															</tr>
															<?php } ?> 
															<?php if(!empty($mca['subject3'])){
														$totamax += 100;
														$totalmin +=40;
														$totalobtcal +=$rowmarks['subject3'];
														?>
															<tr>
																<td style="padding: 5px 60px">
																	<span id=""><?php echo $mca['subject3']; ?></span></td>
																<td align="center">
																	<span id="">100</span></td>
																<td align="center">
																	<span id="">40</span></td>
																<td align="center">
																	<span><span id=""><?php echo $rowmarks['subject3']; ?></span></td>
															</tr>
															<?php } ?>
															
															
															<?php if(!empty($mca['subject4'])){
														$totamax += 100;
														$totalmin +=40;
														$totalobtcal +=$rowmarks['subject4'];
														?>
															<tr>
																<td style="padding: 5px 60px">
																	<span id=""><?php echo $mca['subject4']; ?></span></td>
																<td align="center">
																	<span id="">100</span></td>
																<td align="center">
																	<span id="">40</span></td>
																<td align="center">
																	<span id=""><?php echo $rowmarks['subject4']; ?></span></td>
															</tr>
															<?php } ?>
															<?php if(!empty($mca['subject5'])){
														$totamax += 100;
														$totalmin +=40;
														$totalobtcal +=$rowmarks['subject5'];
														?>
															<tr>
																<td style="padding:5px 60px">
																	<span id=""><?php echo $mca['subject5']; ?></span></td>
																<td align="center">
																	<span id="">100</span></td>
																<td align="center">
																	<span id="">40</span></td>
																<td align="center">
																	<span id=""><?php echo $rowmarks['subject5']; ?></span></td>
															</tr>
															<?php } ?>
															<?php if(!empty($mca['subject6'])){
														$totamax += 100;
														$totalmin +=40;
														$totalobtcal +=$rowmarks['subject6'];
														?>
															<tr>
																<td style="padding:5px 60px">
																	<span id=""><?php echo $mca['subject6']; ?></span></td>
																<td align="center">
																	<span id="">100</span></td>
																<td align="center">
																	<span id="">40</span></td>
																<td align="center">
																	<span id=""><?php echo $rowmarks['subject6']; ?></span></td>
															</tr>
															
															<?php } ?>
															<tr>
																<td align="center" style="padding:5px 60px;">
																	<b>Total Mark Obtain</b></td>
																<td align="center">
																	<span id=""><b></b></span><?php echo $totamax; ?></td>
																<td align="center">
																	<span id=""><b></b></span><?php echo $totalmin; ?></td>
																<td align="center">
																	<span id=""><b></b></span><?php echo $totalobtcal; ?></td>
															</tr>
															
														</tbody>
													</table>
													
												</td>
											</tr>
										</td>
									</tr>
								</tbody>
							</table>
								
						<?php 
							}
						} 
					    }?>
					</div>
							
						</div>
					</div>
				</div>
				<?php include('footer/footer.php'); ?>
		
   </body>
</html>
