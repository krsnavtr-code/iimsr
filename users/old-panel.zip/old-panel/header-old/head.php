
<?php
include('checklogin.php');
$enro = $_SESSION['login'];
$course = $_SESSION['course'];
?>