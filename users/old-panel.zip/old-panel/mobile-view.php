<?php include('dbconnection.php'); ?>
<html>
<head>
    <meta charset="utf-8">
    <meta name="robots" content="Index, Follow" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Student Login Vidya Bharati Institute Of Management & Technology</title>
    <link rel="stylesheet" type="text/css" href="css/stylee.css">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="js/vbimt.js"></script>
</head>
<style> 
    h2.FocusOnLearning {
        margin: -50px 0px 0px 6px;
        font-size: 15px;
    }
    .Comprehensive{
        border-radius:0px;
    }
    .loginformm{
        padding: 0px 0px 0px 0px;
    }
    @media(max-width:992px){
        h2.FocusOnLearning {
            margin: -24px 0px 0px 67px !important;
            font-size: 15px !important;
        }
        .LoginLogoo{
            width: 65% !important;
            height: auto !important;
            margin: 4px 10px 4px 2px !important;
        }
        .cvbcvbcvb{
            width: 100% !important;
            height: 260px !important;
            padding: 0px 0px 0px 0px !important;
        }
    }
    .playimages{
        width: 62%;
        height: 72px;
        margin: 0px 0px 0px 72px;
    }
</style>
<body style="background:white !important; background-size: 100% 100% !important;">
    <div class="container login-container">
        
        <?php 
            $loginn = 'https://www.vbimt.org.in/users/login.php';
            $logenn = '';
            
            if($loginn==1){
                echo 'https://www.vbimt.org.in/users/login.php';
            }elseif($logenn==0){
                echo '<div class="row" style="background-color: #0730e01a; height:100%;">
                        <div class="col-sm-4 col-md-4 col-lg-4 col-xs-2" style="margin: 307px 0px -5px 0px;"><h4 style="text-align:center;">Please click on this link to get your login details and result</h4></div>
                        <div class="col-sm-4 col-md-4 col-lg-4 col-xs-5">
                            <a href="https://play.google.com/store/apps/details?id=com.application.vidyabharti&hl=en"><img src="en_badge_web_generic.png" class="playimages" style="" alt="android"></a>
                        </div>
                        <div class="col-sm-4 col-md-4 col-lg-4 col-xs-5" style="margin: -52px 0px 19px 0px;">
                            <a href="#"><img src="store-apple-mobile-apple.png" class="playimages" style="" alt="android"></a>
                        </div>
                    </div>';
            }
            
        ?>
    </div>
</body>
</html>