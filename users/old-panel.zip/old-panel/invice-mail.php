<?php 
include('session.php');
include("../dbconnect.php");
?>
<?php
$bookingid = $_POST['bookingid'];
$source = $_POST['source'];
$destination = $_POST['destination'];
$departdate = $_POST['departdate'];
$adultname = $_POST['adultname'];
$mail = $_POST['mail'];
$phone = $_POST['phone'];
$totalamount = $_POST['totalamount'];
$amount = $_POST['amount'];
$pendingamount = $_POST['pendingamount'];

$date =  date('d/y i:s');
$invoiceNumber =str_replace("/","",$date);
$invoiceNumber= str_replace(" ","",$invoiceNumber);
$invoiceNumber = str_replace(":","",$invoiceNumber);
$invoiceNumber = uniqid('GOIN');
$date = date('d/m/y');
$grandTotal = $amount+$pendingamount;

$query = "INSERT INTO `invoice`(`bookingid`, `source`, `destination`, `departdate`, `adultname`, `mail`, `phone`, `totalamount`, `amount`, `pendingamount`, `invoiceNumber`, `date`) 
VALUES ('$bookingid','$source','$destination','$departdate','$adultname','$mail','$phone','$totalamount','$amount','$pendingamount','$invoiceNumber','$date')";
$result = mysqli_query($con, $query);


$to = $mail;
$subject = "Invoice email";
$message = "<table width='100%' cellspacing='0' cellpadding='0' class='100p'>
           <tr>
            <td width='100%' valign='top' class='100p'>
                <div>
                    <table width='90%' border='0' cellspacing='0' cellpadding='20' class='100p'>
                        <tr>
                             <td align='top'>
                                <table border='0' cellspacing='0' cellpadding='0' width='100%' class='100p'>
                                    <tr>
                                        <td align='left' width='50%' class='100p'>
    									   <img src='https://goingbo.com/ticket-booking/img/goinbo_mainlogo.png' alt='Logo' border='0' style='display:block' />
    									    <div>www.goingbo.com</div>
    		                                <div>Phone Number: 9990999561</div>
    		                                <div>Email Id: info@goingbo.com</div>
    									</td>
                                        <td width='50%' class='hide' align='right'>
    										<font face='Arial, sans-serif'>
    										&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;<span style='font-size:20px;'>Invoice</span><br> 
    										&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;<span style='font-size:12px;'>Invoice Number - ".$invoiceNumber."</span> <br>
    										&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;<span style='font-size:12px;'>Booking Id - ".$bookingid."</span><br> 
    										&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;<span style='font-size:12px;'>Date - ".$date."</span>
    										</font>
    									</td>
                                    </tr>
                                </table>
    							<hr>
    							<table border='0' cellspacing='0' cellpadding='0' width='100%' class='100p'>
                                    <tr>
                                        <td align='left' width='40%' class='100p'>
                                         <font face='Arial, sans-serif'>
    									  <span style='font-size:12px;'><strong>Booking Detail</strong></span><br>
    									    <span style='font-size:12px;'>".$source." to ".$destination."</span><br>
    		                                <span style='font-size:12px;'>Travel Date - ".$departdate."</span><br>
    		                                <span style='font-size:12px;'>".$adultname."</span>
    		                             </font>      
    									</td>
                                        <td width='20%' class='hide' align='right'>
    										<font face='Arial, sans-serif'>
    										<span style='font-size:12px;'><strong>Total Amount</strong></span><br> 
    										<span style='font-size:12px;'>Rs. ".$totalamount."</span> <br>
    										
    										</font>
    									</td>
    									<td width='20%' class='hide' align='right'>
    										<font face='Arial, sans-serif'>
    										<span style='font-size:12px;'><strong>Paid Amount</strong></span><br> 
    										<span style='font-size:12px;'>Rs. ".$amount."</span> <br>
    										</font>
    									</td>
    									<td width='20%' class='hide' align='right'>
    										<font face='Arial, sans-serif'>
    										<span style='font-size:12px;'><strong>Remaining Amount</strong></span><br> 
    										<span style='font-size:12px;'>Rs. ".$pendingamount."</span> <br>
    										</font>
    									</td>
                                    </tr>
                                </table>
    							<hr>
    							
    							<table border='0' cellspacing='0' cellpadding='0' width='100%' class='100p'>
                                    <tr>
                                        <td align='left' width='50%' class='100p'>
    									   <span style='font-size:12px;'>Total:</span><br>
    									   <span style='font-size:12px;'>Grand Total:</span><br>
    									</td>
                                        <td width='50%' class='hide' align='right'>
    										<font face='Arial, sans-serif'>
    							            <span style='font-size:12px;'><strong>Rs. ".$totalamount."</strong></span><br> 
    										<span style='font-size:12px;'><strong>Rs. ".$grandTotal."</strong></span> <br>
    										</font>
    									</td>
                                    </tr>
                                </table>
    						</td>
                        </tr>
                    </table>
                </div>
            </td>
         </tr>
    </table>";

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <info@goingbo.com>' . "\r\n";
$headers .= 'Cc: support@goingbo.com' . "\r\n";

if(mail($to,$subject,$message,$headers)){
    echo "Invoice has been Sent";
    echo "<script type='text/javascript'> document.location = 'invoice.php'; </script>";
}else{
    echo "Not Send";
}

?>

