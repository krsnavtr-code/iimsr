<?php
session_start();
//$enro=$_SESSION['enrolment'];
include('dbconnection.php');
if (isset($_POST['login'])){
	
	$enl= $_POST['enrolment'];
	$mobile_no = $_POST['mobile_no'];
	$_SESSION['enrolment'] = $enl;
	$query = "SELECT * FROM register_here where `enrolment` ='$enl' and `mobile_no` ='$mobile_no'";
    $result  = $con->query($query);
    $row = mysqli_fetch_array($result);
    $count = mysqli_num_rows($result);	
    if($count == 1) {
        // session_register("username");
         $_SESSION['login'] = $enl;
         $_SESSION['course'] = $row['course'];
        header("location: index.php");
      }else {
         $error = "Your Login Name or Password is invalid";
         echo $error;
      }
    }    
?> 	
<html>
<head>
<meta charset="utf-8">
<meta name="robots" content="Index, Follow" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Student Login Vidya Bharati Institute Of Management & Technology</title>
<link rel="stylesheet" type="text/css" href="css/stylee.css">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="js/vbimt.js"></script>

</head>
<style>
    h2.FocusOnLearning {
        margin: -50px 0px 0px 6px;
        font-size: 15px;
    }
    .Comprehensive{
        border-radius:0px;
    }
    .loginformm{
        padding: 0px 0px 0px 0px;
    }
    @media(max-width:992px){
        h2.FocusOnLearning {
            margin: -24px 0px 0px 67px !important;
            font-size: 15px !important;
        }
        .LoginLogoo{
            width: 65% !important;
            height: auto !important;
            margin: 4px 10px 4px 2px !important;
        }
        .cvbcvbcvb{
            width: 100% !important;
            height: 260px !important;
            padding: 0px 0px 0px 0px !important;
        }
    }
</style>
<body style="background:white !important; background-size: 100% 100% !important;">
    <div class="container login-container">
        <div class="row"id="student">
            <div class="col-sm-3 col-md-3 col-lg-3 col-xs-12 login-form-1">
				<a href="http://vbimt.org.in/"><img src="logo.png" class="LoginLogoo" style="width:85%; height:auto;margin: 21px 0px 61px 0px;"title="White flower" alt="Flower"></a>
				<h2 class="FocusOnLearning"><b><i>Focus On Comprehensive Learning</i></b></h2>	
            </div>
			<div class="col-sm-5 col-md-5 col-lg-5 col-xs-12 loginformm">
				<img src="images/travel-course.jpeg" class="cvbcvbcvb" style="width:100%; height:300px; padding:0px 0px 0px 0px;"title="White flower" alt="Flower">
            </div>
            <div class="col-sm-4 col-md-4 col-lg-4 col-xs-12 login-form-2">
			    <div style="text-align:center;"></div>
                <h3> Student Login</h3>
				<p style="text-align:center; color:#fff;">Kindly Enter your credentials to access the student section</p>
				<form class="form" action="" method="post">
					<div class="form-group">
						<input type="text" class="form-control Comprehensive" name="enrolment" placeholder="Enrolment*" value="" required>
					</div>
					<div class="form-group">
					  <input type="dob" class="form-control Comprehensive" name="mobile_no" id="mobile_no" placeholder="Mobile No" value="" required>
					</div>
					<div class="form-group center-block">
					<center>
						<input type="submit" name="login" class="btnSubmit Comprehensive" value="Login" />
						</center>
					</div>
					<div class="form-group">
						<!--<a href="forget-password.php" class="ForgetPwd Comprehensive" value="Login" style="float:right; margin: -39px 0px 0px 0px;">Forget Password?</a>-->
					</div>
				</form>
            </div>
        </div>
    </div>
</body>
</html>