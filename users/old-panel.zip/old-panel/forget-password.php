<!DOCTYPE html>
<html>
<head>

	<title>Registration system PHP and MySQL</title>
	<link rel="stylesheet" type="text/css" href="stylee.css">
	<link rel="stylesheet" type="text/css" href="css/stylee.css">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
</head>
	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />

<body>
    <div class="container login-container">
            <div class="row">
                <div class="col-md-6 login-form-1">
					<a href="http://vbimt.org.in/"><img src="logo.png" style="width:100%; height:auto; margin: 64px 10px 64px 10px;"title="White flower" alt="Flower"></a>
					<h2><b><i>Focus On Comprehensive Learning</i></b></h2>
                </div>
                <div class="col-md-6 login-form-2">
                    <h3> Create New Password</h3>
					
                    <form id="login-form" class="form" action="login.php" method="post">
					  
                        <div class="form-group">
                            <input type="text" class="form-control" name="enrolment" placeholder="Username*" value="" required>
                        </div>
						<div class="form-group">
						  <input type="Password" class="form-control" name="password" id="exampleInputpass" placeholder="New Password" required>
					    </div>
						<div class="form-group">
						  <input type="Password" class="form-control" name="password" id="exampleInputpass" placeholder="Confirm Password" required>
					    </div>
                        <div class="form-group">
						<center>
                            <input type="submit" class="btnSubmit" value="submit" />
							</center>
                        </div>
                        <div class="form-group">
                            <p>
								Please Sign Here <a href="login.php" class="signincolor">Sign in</a></p>
                            <a href="forget-password.php" class="ForgetPwd" value="Login" style="float:right; margin: -39px 0px 0px 0px;">Forget Password?</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
</body>


