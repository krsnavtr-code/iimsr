<?php 
include('checklogin.php');
include("dbconnection.php");
?>

<!DOCTYPE html >
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8">
    <meta name="robots" content="Index, Follow" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">	
	<title>VBIMT Admit Card</title>
	<link rel="stylesheet" type="text/css" href="css/csss.css" />	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script src="js/vbimtlandingpage.js"></script>
	
</head>
<body style="background-color:#dbdbff;">
	<div class="container" style="background-color:#fff;">
		<div class="row" id="top-bar">
    	    <div class="col-sm-8 col-md-8 col-lg-8 col-xs-8">
    			<a href="http://vbimt.org.in/"><img src="logo.png" alt="DZone" class="floatleft AdminPanelLogo" /></a>
    		</div>	
		<div class="col-sm-4 col-md-4 col-lg-4 col-xs-4">
            <div class="topmeenu">
                <a href="logout.php"><button type="button" class="btn btn-danger AdminLogoutBu">Logout</button></a>
        	</div>
            <div class="topm"></div>
	    </div>
	</div>
		<style>
    		.AdminPanelLogo {
            	height: 56px;
            	width: 200px;
            }
		    /*.floatleft {
                width: 262px;
                height: 72px;
            }*/
		    .sdgfgf{
		        margin: 0px 0px 0px 167px;
		    }
            ul.sdfsdfdsfds {
                margin: 0px 0px 0px 167px;
            }
		    .admitcard{
                margin-right: 10px;
                margin-left: 10px;
                padding:20px;
            }
             .vbimt_name{
                padding:15px;
                
                margin: 5px 9px 5px 11px;
            }
            .vbimt_fname{
                padding:15px;
                
                margin:5px 0px 5px 0px;
            }
            .vbimt_cname{
                margin: 18px 0px 10px 0px;
            }
            .vbimt_semname{
                margin: 18px 0px 10px 0px;
            }
            .vbimt_ename{
                margin: 10px 0px 10px 0px;
            }
            .vbimt_ecname{
                margin:10px 0px 10px 0px;
            }
            .vbimt_sename{
                margin: 10px 0px 10px 0px;
            }
            .vbimt_sidebaar{
                margin: -11px 0px 0px -21px;
            }
            .vbimt_ecnname{
                margin: 10px 0px 10px 0px;
            }
            .fhdbhff{
                border-radius:0px;
            }
            .fgfggfgfg{
                margin: 2px 0px 25px 0px;
                padding: 20px 20px 20px 20px;
                background-color: #bebeff36;
            }
            form.form-contentset {
                margin: 13px 0px -3px 0px;
                padding: 8px 20px 20px 20px;    
                /*margin: 25px 0px -3px 0px;
                padding: 20px 20px 20px 20px;*/
                background-color: #bebeff36;
            }
            .vbimt-downloadb{
                border-radius: 0px;
                padding: 7px 20px 7px 20px;
                margin: 0px 2px 3px 0px;
            }
            .dfgfgdfgdfgd {
                padding: 0px 0px 0px 0px;
            }
            .jghjgttyutyu{
                font-weight:700;
                font-size:16px;
                margin: -38px 2px -10px 0px;
            }
            .fgfggfgfghg {
                margin-top: -28px;
            }
            .enrollmentngg {
                border-radius: 0px;
                border: #0000fd73 1px solid;
            }
            .Preview{
               margin-top: -28px; 
            }
            .modal-dialog {
                width: 1000px;
                margin: 5px auto;
            }
            .Previewicard {
                margin-right: -11px;
                margin-left: -11px;
                padding: 8px;
            }
            .modal-open .modal {
                overflow-x: hidden;
                overflow-y: auto;
                z-index: 999999;
            }
            .previewidcard{
                font-size:13px;
                font-weight:700;
            }
            .namenn {
                font-size:14px;
                margin-left: 54px;
            }
            .sdobn {
                font-size:14px;
                margin-left: 62px;
            }
            .coursen {
                font-size:14px;
                margin-left: 42px;
            }
            .sessionb {
                font-size:14px;
                margin-left: 37px;
            }
            .colsmmdlg {
                margin: 0px 0px 0px 0px;
            }
            .father_namen {
                margin-left: 3px;
            }
            .idcardd{
                margin-top: 5px;
                margin-bottom: 5px;
                border: 0;
                border-top: 1px solid #eee;
            }
            .floatleft.AdminPanelLogo {
                width: 200px;
                height: auto;
            }
            .AdminLogoutBu {
                border-radius: 0px !important;
                padding: 7px 13px 7px 13px !important;
            }
		    .floatleft {
                width: 262px;
                height: 72px;
            }
		    .admitcard{
                margin-right: 32px;
                margin-left: 32px;
                border:1px #000 solid;
                padding:20px;
            }
            .vbimt_name{
                padding:7px;
                border:1px #000 solid;
                margin: 5px 9px 5px 11px;
            }
            .vbimt_fname{
                padding:7px;
                border:1px #000 solid;
                margin:5px 0px 5px 0px;
            }
            .vbimt_cname{
                padding:7px;
                border:1px #000 solid;
                margin: 5px 10px 5px 10px;
            }
            .vbimt_ename{
                padding:7px;
                border:1px #000 solid;
                margin:5px 9px 5px 9px;
            }
            .vbimt_ecname{
                padding:7px;
                border:1px #000 solid;
                margin:5px 0px 5px 0px;
            }
            .vbimt_sename{
                padding:7px;
                border:1px #000 solid;
                margin:5px 0px 5px 0px;
            }
            .ddrrgfffg{
                width: 92.8%;
                padding:7px;
                border:1px #000 solid;
                margin:5px 0px 5px 11px;
            }
            .gdgdgdg{
                font-size:14px;
                font-weight:700;
                margin-top:-13px;
            }
            .ex1 {
              width: 100%;
              height: 450px;
              overflow-x: auto;
            }
             .floatleft.AdminPanelLogo {
                width: 200px;
                height: auto;
            }
            .AdminLogoutBu {
                border-radius: 0px !important;
                padding: 7px 13px 7px 13px !important;
            }
            .topmeenu {
                float: right;
                margin: 51px 2px -83px 0px !important;
                padding: 10px 0px 0px 0px;
            }
            .Kindlydeposit{
                color:red; 
                font-weight:bold;
                font-size:14px;
                text-align:justify;
            }
            @media(max-width:992px){
                .Kindlydeposit{
                    color:red !important;
                    font-weight:bold !important;
                    font-size:10px !important;
                }
                .topmeenu {
                    border-radius: 0px !important;
                    float: right !important;
                    margin: 0px 0px -70px 0px !important;
                } 
            }
		</style>
		<?php include('header/header.php'); ?>
            <div class="admitcard">
                <div id="feature" ><h4 class="gdgdgdg" style="text-align:center;"><b>I'Card</b></h4></div>
                    <?php 
        			    $enrol = $_SESSION['enrolment'];
        	        	$query = mysqli_query($con, "select * from `student_icard` WHERE `enrolment`='$enrol'");
        				while ($row = mysqli_fetch_array($query)){
        				    $course = $row['course'];
        		    ?>
                    <div class="row">
                        <!--------------<table>
                            <tr>
                                <th rowspan="4">Favorite</th>
                                <th>Color</th>
                                <td>Blue</td>
                            </tr> 
                            <tr>
                                <th>Flavor</th>
                                <td>Banana</td> 
                            </tr>
                            <tr>
                                <th>Color</th>
                                <td>Yellow</td> 
                            </tr>
                            <tr>
                                <th>Flavor</th>
                                <td>Mint</td>
                            </tr>
                        </table>------------>
                        <div class="col-sm-4 col-md-3 col-lg-3 col-xs-12"></div>
                        <div class="col-sm-6 col-md-6 col-lg-6 col-xs-12">
                            <img src="/admin/images/logo.png" alt="student image" style="width:315px; height:77px;margin: 0px 0px 0px 5px;"></span>
                            <hr class="idcardd">
                            <div class="row">
                                <div class="col-sm-2 col-md-2 col-lg-2 col-xs-12 colsmmdlg">
                                    <span><img src="/admin/images/<?php echo $row['stuimage'];?>" alt="student image" style="width:111px; height:108px;margin-left:0px;"></span>
                                </div>
                                <div class="col-sm-10 col-md-10 col-lg-10 col-xs-12">
                                    <span class="previewidcard">Name </span><span class="namenn">:<?php echo strtoupper($row['name']);?></span><br>
                                    <span class="previewidcard">Father Name </span><span class="father_namen">:<?php echo $row['father_name'];?></span><br>
                                    <span class="previewidcard">DOB </span><span class="sdobn">:<?php echo $row['sdob'];?></span><br>
                                    <span class="previewidcard">Course </span><span class="coursen">:
                                    <?php 
                                        if($course=="Advance Diploma In Business Administration" ){
                                        	$Sep = "Sep";
                                        }
                                        elseif($course=="Advance Diploma In Civil Engineering" ){
                                        	echo "Advance";
                                        }
                                        elseif($course=="Advance Diploma In Computer Science Engineering" ){
                                        	echo "Advance";
                                        }
                                        elseif($course=="Advance Diploma in Electrical Engineering" ){
                                        	echo "Advance";
                                        }
                                        elseif($course=="Advance Diploma in H.R. Management" ){
                                        	echo "Advance";
                                        }
                                        elseif($course=="Advance Diploma In Hardware & Networking Technology" ){
                                        	echo "Advance";
                                        }
                                        elseif($course=="Bachelor Programme In Animation And Multimedia Technology"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme in Automobile Engineering"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme In Business Administration"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme In Chemical Engineering"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme in Civil Engineering"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme In Computer Applications"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme In Computer Science Engineering"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme In Electrical & Electronics Engineering"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme In Electrical Engineering"){
                                            echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme in Electronics & Communication Engineering"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme In Electronics & Telecommunication Engineering"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme in Electronics Engineering"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme In Fire & Safety Engineering"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme In Food & Nutrition"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme In Food Technology"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme in Information Technology"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme In Instrumentation Engineering"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme in Mechanical Engineering"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme In Metallurgical Engineering"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme In Polymer Engineering"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor programme In Print Technology Management"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Bachelor Programme In Textile Engineering"){
                                        	echo "Bachelor";
                                        }
                                        elseif($course=="Certificate Programme In Civil Engineering"){
                                        	echo "Certificate";
                                        }
                                        elseif($course=="Certificate Programme In Librarian"){
                                        	echo "Certificate";
                                        }
                                        elseif($course=="Certificate Programme In Project Management" ){
                                            echo "Certificate";
                                        }
                                        elseif($course=="Diploma in Electrical Engineering"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma in Human Resource Management" ){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma In Industrial Safety" ){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma In Material Management 2 Year"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma In Operation Management"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Automobile Engineering"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme in Chemical Engineering"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Civil Engineering"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Computer Applications" ){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Computer Science Engineering"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Disaster Management"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Electrical & Electronics Engineering"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme in Electrical Engineering"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Electronics & Communication Engineering"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Electronics & Telecommunication"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Electronics Engineering"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Finance Management" ){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Fire & Safety" ){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Food & Safety"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Hotel Management"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In HR" ){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Industrial Electronics"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Information Technology"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Inventory Management"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Logistic"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Logistic Management" ){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Mechanical Engineering"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Mechanical Engineering"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme in Metallurgical Engineering"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Printing Technology"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Project Management" ){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Rural Development" ){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Supply Chain Management" ){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Textile"){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Diploma Programme In Tourism Management" ){
                                        	echo "Diploma";
                                        }
                                        elseif($course=="Executive Master In Business Administration" ){
                                        	echo "Executive";
                                        }
                                        elseif($course=="Graduate Diploma In Automobile Engineering"){
                                        	echo "Graduate";
                                        }
                                        elseif($course=="Graduate Diploma In Civil Engineering"){
                                        	echo "Graduate";
                                        }
                                        elseif($course=="Graduate Diploma In Computer Science"){
                                        	echo "Graduate";
                                        }
                                        elseif($course=="Graduate Diploma In Electronics & Telecommunication"){
                                       	    echo "Graduate";
                                        }
                                        elseif($course=="Graduate Diploma In Hotel Management"){
                                       	    echo "Graduate";
                                        }
                                        elseif($course=="Graduate Diploma In Information Technology"){
                                        	echo "Graduate";
                                        }
                                        elseif($course=="Graduate Diploma In Mechanical Engineering"){
                                        	echo "Graduate";
                                        }
                                        elseif($course=="Master Programme in Business Administration"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme In Business Administration ( Marketing)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme in Business Administration (Agri & Food Busi.)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme In Business Administration (Construction Management)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme in Business Administration (Digital Management)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme In Business Administration (Finance & Marketing)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme In Business Administration (Finance Management)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme In Business Administration (General management)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme In Business Administration (Hotel Management)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme in Business Administration (Human Resources)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme In Business Administration (Information Technology)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme in Business Administration (International Business)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme In Business Administration (Logistics,Supply chain & Marketing)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme in Business Administration (Marketing Management)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme in Business Administration (Oil & Gas)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme in Business Administration (Operations & Supply Chain Management)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme in Business Administration (Petroleum Industry)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme in Business Administration (Pollution Control)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme In Business Administration (Production & Operation Management)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme In Business Administration (Quality Management)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme In Business Administration (Security Management)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme In Business Administration (Supply Chain Management)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme In Business Administration in Dual Specializations (Logistics,Supply chain & Marke"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme In Business Administration in Dual Specializations (Supply chain & logistics suppl"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme In Business Administration In Dual Specializations (HR & finance management)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme In Business Administration(Marketing Mgmt & Production Operation Mgmt)"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master Programme In Business Management"){
                                        	echo "Master";
                                        }
                                        elseif($course=="Master programme in Computer Application"){
                                        	echo "Master";
                                        }
                                        elseif($course=="P G Diploma In Business Management"){
                                        	echo "P G Diploma";
                                        }
                                        elseif($course=="P G Diploma In Computer Application"){
                                        	echo "P G Diploma";
                                        }
                                        elseif($course=="P G Diploma In Environment Management" ){
                                        	echo "P G Diploma";
                                        }
                                        elseif($course=="P G Diploma In Fire & Construction" ){
                                        	echo "P G Diploma";
                                        }
                                        elseif($course=="P G Diploma In Hospital & Health Management" ){
                                        	echo "P G Diploma";
                                        }
                                        elseif($course=="P G Diploma In Industrial And Environment Management" ){
                                        	echo "P G Diploma";
                                        }
                                        elseif($course=="P G Diploma In Industrial Safety" ){
                                        	echo "P G Diploma";
                                        }
                                        elseif($course=="P G Diploma In International Business"){
                                        	echo "P G Diploma";
                                        }
                                        elseif($course=="P G Diploma in Project Management" ){
                                        	echo "P G Diploma";
                                        }
                                        elseif($course=="P G Diploma in Public Health" ){
                                        	echo "P G Diploma";
                                        }
                                        elseif($course=="P G Diploma In Rural Development" ){
                                        	echo "P G Diploma";
                                        }
                                        elseif($course=="P G Diploma In Security & Threat Control" ){
                                        	echo "P G Diploma";
                                        }
                                        elseif($course=="Professional Diploma In Business Analytics" ){
                                        	echo "Professional";
                                        }
                                        elseif($course=="Professional Diploma in Digital Marketing" ){
                                        	echo "Professional";
                                        }
                                        elseif($course=="Professional Diploma In Fashion Designing" ){
                                        	echo "Professional";
                                        }
                                        elseif($course=="Professional Diploma In Financial Analytics" ){
                                        	echo "Professional";
                                        }
                                        elseif($course=="Professional Diploma In Financial Mathematics" ){
                                        	echo "Professional";
                                        }
                                        elseif($course=="Professional Diploma In Graphic Designing" ){
                                        	echo "Professional";
                                        }
                                        elseif($course=="Professional Diploma In Interior Designing" ){
                                        	echo "Professional";
                                        }
                                        elseif($course=="Professional Diploma In Tourism Management" ){
                                        	echo "Professional";
                                        }else{
                                        	echo "";
                                        }
                                    ?>
                                    </span><br>
                                    <span class="previewidcard">Session </span><span class="sessionb">:<?php echo $row['session'];?></span><br>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 col-md-4 col-lg-4 col-xs-12"></div>
                    </div>
                    <?php } ?>
                
            </div>
            
            <!---------------------------------------------------------------------------------------------------------------------------------->
			<!---------------------------------------------------------------------------------------------------------------------------------->
            <br><br>
            <div class="row">
        		<div class="col-sm-12 col-md-12 col-lg-12 col-xs-12">
                    <p class="Kindlydeposit">Kindly deposit your fees in VIDYA BHARATI INSTITUTE MANAGEMENT & TECHNOLOGY account only, any fee deposited in any other account EXCEPT VBIMT will not be considered.<span style="color:#160fe8"> For any issue related to fees or examination please call @ 9266585858</span></p>
                </div>
            </div>
            <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xs-12">
            	<div id="footer">
            		© VBIMT Advance System Integration.
            		<div class="footermenu"><a href="https://www.vbimt.org.in/">Home</a> | <a href="https://www.vbimt.org.in/privacy-policy">Privacy policy</a> | <a href="https://www.vbimt.org.in/contact">Contact us</a></div>
            	</div>
                <?php //include('footer/footer.php'); ?>
            </div>
        </div>
        </div>
    </div>
</body>
<script>
    $('document').ready(function(){
        
        	$('#payBtn').on('click',function(e){
        		e.preventDefault();
        		$('#myModal').modal('toggle');
        
        	});
        
        	$('#continuebtn').on('click',function(){
        
        		$('form').submit();
        	});
        });    
</script>
<script>
    let print = (doc) => {
    	let objFra = document.createElement('iframe');
        objFra.style.visibility = 'hidden';
        objFra.src = doc;

        document.body.appendChild(objFra);

        objFra.contentWindow.focus();
        objFra.contentWindow.print();
    }
</script>
    <script>
        function exportTableToExceel(tableID, filename = ''){
            var downloadLink;
            var dataType = 'application/vnd.ms-excel';
            var tableSelect = document.getElementById(tableID);
            var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
            filename = filename?filename+'.xls':'excel_data.xls';
            downloadLink = document.createElement("a");
            document.body.appendChild(downloadLink);
            if(navigator.msSaveOrOpenBlob){
                var blob = new Blob(['\ufeff', tableHTML], {
                    type: dataType
                });
                navigator.msSaveOrOpenBlob( blob, filename);
            }else{
                downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
                downloadLink.download = filename;
                downloadLink.click();
            }
        }
    </script>
   <script>
        function randomStringToInput(clicked_element)
        {
            var self = $(clicked_element);
            var random_string = generateRandomString(10);
            $('input[name=emp]').val(random_string);
            self.remove();
        }
        function generateRandomString(string_length)
        {
            var characters = 'VBIMT0123456789';
            var string = '';
            for(var i = 0; i <= string_length; i++)
            {
                var rand = Math.round(Math.random() * (characters.length - 1));
                var character = characters.substr(rand, 1);
                string = string + character;
            }
            return string;
        }
    </script>
</html>