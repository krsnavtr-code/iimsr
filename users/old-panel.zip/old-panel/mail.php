<?php 
include('session.php');
include("../dbconnect.php");
?>
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />
<?php
$source = $_POST['source'];
$destination = $_POST['destination'];
$departdate = $_POST['departdate'];
$departdater = $_POST['departdater'];
$adult = $_POST['adult'];
$child = $_POST['child'];
$adultname = $_POST['adultname'];
$mail = $_POST['mail'];
$phone = $_POST['phone'];
$paymentdeadline = $_POST['paymentdeadline'];
$totalamount = $_POST['totalamount'];
$amount = $_POST['amount'];
$bookeddate = date('d-m-y h:i:d'); 
$date =  date('d/y i:s');
$id =str_replace("/","",$date);
$id= str_replace(" ","",$id);
$id = str_replace(":","",$id);
$id = uniqid('INSD');
$query = "INSERT INTO `booking_info`(`source`, `destination`, `departdate`, `returndate`, `adult`, `child`, `adultname`, `mail`, `phone`, `paymentdeadline`, `totalamount`, `amount`, `bookeddate`, `booking_id`, `date`)
VALUES ('$source','$destination','$departdate','$departdater','$adult','$child','$adultname','$mail','$phone','$paymentdeadline','$totalamount','$amount','$bookeddate','$id','$date')";
$result = mysqli_query($con, $query);
$to = $mail;
$subject = "Package Confirmation email";
$message ='<div>
    <table width="100%" bgcolor="#eaeaea" cellpadding="0" cellspacing="0" border="0" id="m_-3150665402647626555m_267825655353094048backgroundTable">
        <tbody>
            <tr>
                <td style="padding-top:10px">
                    <table width="630" cellpadding="15" bgcolor="#ffffff" cellspacing="0" border="0" align="center" class="m_-3150665402647626555m_267825655353094048devicewidth" style="padding-top:2em;border-top-left-radius:7px;border-top-right-radius:7px;border-bottom:1px solid #cccccc;margin:0 auto">
                        <tbody>
                            <tr>
                                <td width="100%">
                                    <table width="100%" align="left" border="0" cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td align="left" bgcolor="#ffffff" width="40%">
                                                    
                                                        <a href="https://goingbo.com" rel="noreferrer" target="_blank" data-saferedirecturl="https://goingbo.com">
                                                            <img width="120" border="0" alt="" style="display:block;border:none;outline:none;text-decoration:none;padding-bottom:18px;" src="https://goingbo.com/images/goinbo_mainlogo.png" class="CToWUd">
                                                        </a>
                                                    
                                                </td>
                                                 <td width="45%" valign="middle" align="right">
                                                    <p style="font-family:Helvetica,arial,sans-serif;font-size:15px;color:#9b9b9b;margin:0;margin-bottom:5px">Booking ID: <span style="color:#000000;font-weight:bold;font-size:18px">'.$id.'</span></p>
                                                    <p style="font-family:Helvetica,arial,sans-serif;font-size:12px;color:#9b9b9b;margin:0">Booked on: '.$bookeddate.'</p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
    
    <table width="100%" bgcolor="#eaeaea" cellpadding="0" cellspacing="0" border="0" id="m_-3150665402647626555m_267825655353094048backgroundTable">
        <tbody>
            <tr>
                <td>
                    <table width="630" cellpadding="0" cellspacing="0" border="0" align="center" class="m_-3150665402647626555m_267825655353094048devicewidth" style="background:#ffffff;margin:0 auto">
                        <tbody>
                            <tr>
                                <td width="100%" style="padding:20px">
                                    <table width="100%" align="left" cellpadding="0" cellspacing="0" border="0" class="m_-3150665402647626555m_267825655353094048devicewidthinner">
                                        <tbody>
                                        
                                            <tr>
                                                <td>
                                                    
                                                    <h1 style="font-family:Helvetica,arial,sans-serif;font-size:35px;color:#333333;text-align:left;line-height:1.3" class="m_-3150665402647626555m_267825655353094048emparaTxt">Booking Confirmed</h1>
                                                    
                                                    <p style="font-family:Helvetica,arial,sans-serif;font-size:16px;color:#4a4a4a;font-weight:bold;line-height:25px;text-align:left;margin-top:15px;margin-bottom:0;display:inline-block;padding:0" class="m_-3150665402647626555m_267825655353094048emparaTxt">Dear '.$adultname.'<br>Thank you for choosing goingbo</p>
                    
                                                    <p class="m_-3150665402647626555m_267825655353094048contentTxt" style="color:#4a4a4a;font-family:Helvetica,arial,sans-serif;font-size:16px;line-height:25px;margin-top:15px;margin-bottom:0px;padding:0">
                                                        Your booking is confirmed. No need to call us to reconfirm this booking.
                                                    </p>

                                                    <p class="m_-3150665402647626555m_267825655353094048contentTxt" style="color:red;font-family:Helvetica,arial,sans-serif;font-size:16px;line-height:25px;margin-top:15px;margin-bottom:0px;padding:0">
                                                    </p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
    
    
    <table width="100%" bgcolor="#eaeaea" cellpadding="0" cellspacing="0" border="0" id="m_-3150665402647626555m_267825655353094048backgroundTable">
        <tbody>
            <tr>
                <td width="100%">
                    <table bgcolor="#ffffff" width="630" cellpadding="0" cellspacing="0" border="0" align="center" class="m_-3150665402647626555m_267825655353094048devicewidth" style="margin:0 auto">
                        <tbody>
                            
                            <tr>
                                <td style="padding:0 30px" width="100%">
                                    <table cellpadding="0" cellspacing="0" border="0" class="m_-3150665402647626555m_267825655353094048devicewidthinner" width="100%">
                                        <tbody><tr>
                                            <td width="100%" style="padding:0px 0">
                                                
                                                <table width="100%" align="left" border="0" cellpadding="0" cellspacing="0" class="m_-3150665402647626555m_267825655353094048devicewidth">
                                                    <tbody>
                                                        <tr>
                                                            <td width="100%" align="left" class="m_-3150665402647626555m_267825655353094048devicewidth" style="padding:5px 20px 5px 0">
                                                                   
                                                                    <a href="https://goingbo.com" rel="noreferrer" target="_blank" data-saferedirecturl="https://goingbo.com">
                                                                    <img class="m_-3150665402647626555m_267825655353094048responsiveImg CToWUd" src="https://goingbo.com/ticket-booking/img/Traveloka-Flight-Hotel-Package.jpg" width="500" alt="Supporting image 1"></a>
                                                                    
                                                            </td>
                                                        </tr>
                                                     </tbody>
                                                </table>
                                                
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:10px 30px" width="100%">
                                    
                                    <table border="0" cellpadding="0" cellspacing="0" class="m_-3150665402647626555m_267825655353094048devicewidthinner" width="100%">
                                        <tbody>
                                            <tr>
                                                <td width="100%" class="m_-3150665402647626555m_267825655353094048devicewidth" style="border-bottom:1px solid #d8d8d8;padding:10px 0 15px 0">
                        
                                                    <table width="100%" cellpadding="0" cellspacing="0" align="left" class="m_-3150665402647626555m_267825655353094048devicewidth">
                                                        <tbody>
                                                            <tr>
                                                                
                                                                <td style="width:38px;height:35px;max-width:38px">
                                                                    <a href="http://www.goingbo.com/" rel="noreferrer" target="_blank" data-saferedirecturl="goingbo.com" class="CToWUd"></a>
                                                                </td>
                                                                <td style="width:150px;max-width:150px;float:left">
                                                                <a href="https://goingbo.com" style="text-decoration:none" rel="noreferrer" target="_blank" data-saferedirecturl="https://goingbo.com"><span style="padding:7px 0;float:left;font-family:Helvetica,arial,sans-serif;font-size:14px;color:#2962aa;display:inline-block">Manage Booking</span></a>
                                                                </td>
                                                                
                                                            </tr>
                                                        </tbody>
                                                    </table>
                        
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    
                                </td>
                            </tr>

							<tr>
                                <td style="padding:0 30px" width="100%">
                                    <table cellpadding="0" cellspacing="0" width="100%" class="m_-3150665402647626555m_267825655353094048devicewidthinner">
                                        <tbody>
                                            <tr>
                                                <td width="100%" style="border-bottom:1px solid #cccccc;padding-bottom:20px">
                                                    <p style="font-family:Helvetica,arial,sans-serif;font-size:14px;color:#858585;margin:0;padding-bottom:5px">Guest Name</p>
                                                    <span style="font-family:Helvetica,arial,sans-serif;font-size:18px;display:inline-block"><img style="float:left;padding-right:10px" src="https://goingbo.com/ticket-booking/img/unnamed.png" class="CToWUd">
                                                     '.$adultname.'  
                                                    </span>

                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:0 30px" width="100%">
                                    <table cellpadding="0" cellspacing="0" border="0" width="100%">
                                        <tbody><tr>
                                            <td width="100%" style="border-bottom:1px solid #d8d8d8;padding:15px 0">
                                                
                                                <table width="270" align="left" border="0" cellpadding="0" cellspacing="0" class="m_-3150665402647626555m_267825655353094048devicewidth">
                                                    <tbody>
                                                        <tr>
                                                            <td width="270" align="left" style="padding:5px 0">
                                                                <table width="100%" cellspacing="0" cellpadding="0">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td width="45%">
                                                                                <p style="font-family:Helvetica,arial,sans-serif;font-size:18px;color:#000000;margin:0;padding-bottom:4px">Departure Date</p>
                                                                                
                                                                                    <p style="font-family:Helvetica,arial,sans-serif;font-size:16px;color:#000000;margin:0;padding-top:2px">'.$departdate.'</p>
                                                                                
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                     </tbody>
                                                </table>
                                                
                                                <table width="270" align="left" border="0" cellpadding="0" cellspacing="0" class="m_-3150665402647626555m_267825655353094048devicewidth">
                                                    <tbody>
                                                        <tr>
                                                            <td width="270" align="left" style="padding:5px 0">
                                                                <table width="100%" cellspacing="0" cellpadding="0">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td>
                                                                                <p style="font-family:Helvetica,arial,sans-serif;font-size:18px;color:#000000;margin:0;padding-bottom:4px">Return Date</p>
                                                                                <p style="font-family:Helvetica,arial,sans-serif;font-size:16px;color:#000000;margin:0;padding-top:2px">'.$departdater.'</p>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>

                                                
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:0 30px" width="100%">
                                    <table cellpadding="0" cellspacing="0" border="0" class="m_-3150665402647626555m_267825655353094048devicewidthinner" width="100%">
                                        <tbody><tr>
                                            <td width="100%" style="border-bottom:1px solid #d8d8d8;padding:15px 0">
                                                
                                                <table align="left" border="0" cellpadding="0" cellspacing="0" class="m_-3150665402647626555m_267825655353094048devicewidth">
                                                    <tbody>
                                                        <tr>
                                                            <td width="100%" align="left" class="m_-3150665402647626555m_267825655353094048devicewidth" style="padding:5px 0">
                                                                <table width="100%" cellspacing="0" cellpadding="0">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td width="45%">
                                                                                <p style="font-family:Helvetica,arial,sans-serif;font-size:14px;color:#858585;margin:0;width:100%;float:left;padding-bottom:5px">Received Amount</p>
                                                                                <span style="font-family:Helvetica,arial,sans-serif;font-size:18px;display:inline-block">'.$amount.'</span>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                     </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                            <tr>
                                    <td style="padding:0 30px">
                                        <table cellpadding="0" cellspacing="0" width="100%" class="m_-3150665402647626555m_267825655353094048devicewidthinner">
                                            <tbody>
                                                <tr>
                                                    <td width="100%" style="border-bottom:1px solid #cccccc;padding:20px 0" class="m_-3150665402647626555m_267825655353094048devicewidth">
                                                        <p style="font-family:Helvetica,arial,sans-serif;font-size:18px;color:#767505;margin:0;padding-top:2px">Promo Code Applied: FLAT150</p>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                
								<tr>
                                    <td style="padding:0 30px">
                                        <table cellpadding="0" cellspacing="0" width="100%" class="m_-3150665402647626555m_267825655353094048devicewidthinner">
                                            <tbody>
                                                <tr>
                                                    <td width="100%" style="border-bottom:1px solid #cccccc;padding:20px 0" class="m_-3150665402647626555m_267825655353094048devicewidth">
                                                        <p style="font-family:Helvetica,arial,sans-serif;font-size:18px;color:#767505;margin:0;padding-top:2px">You saved Rs. 150 on this booking</p>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                
                            <tr>
                                <td style="padding:0 30px" width="100%">
                                    <table cellpadding="0" cellspacing="0" width="100%" class="m_-3150665402647626555m_267825655353094048devicewidthinner">
                                        <tbody>
                                            <tr>
                                                <td width="100%" style="padding-bottom:10px">
                                                    <span style="font-family:Helvetica,arial,sans-serif;font-weight:bold;font-size:18px;color:#4a4a4a;display:inline-block">PASSANGER DETAILS</span>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:0 30px" width="100%">
                                    <table cellpadding="0" cellspacing="0" border="0" class="m_-3150665402647626555m_267825655353094048devicewidthinner" width="100%">
                                        <tbody><tr>
                                            <td width="100%" style="border-bottom:1px solid #d8d8d8;padding:15px 0">
                                                
                                                <table width="170" align="left" border="0" cellpadding="0" cellspacing="0" class="m_-3150665402647626555m_267825655353094048devicewidth">
                                                    <tbody>
                                                        <tr>
                                                            <td width="170" align="left" class="m_-3150665402647626555m_267825655353094048devicewidth" style="padding:5px 0">
                                                                <table width="100%" cellspacing="0" cellpadding="0">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td width="30%">
                                                                               <span style="font-family:Helvetica,arial,sans-serif;font-weight:bold;font-size:15px;display:inline-block;color:#4a4a4a;padding-right:10px">Number of Guests</span>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                     </tbody>
                                                </table>
                                                
                                                
                                                <table width="370" align="left" border="0" cellpadding="0" cellspacing="0" class="m_-3150665402647626555m_267825655353094048devicewidth">
                                                    <tbody>
                                                        <tr>
                                                            <td width="370" align="left" class="m_-3150665402647626555m_267825655353094048devicewidth" style="padding:5px 0">
                                                                <table width="100%" cellspacing="0" cellpadding="0">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td>
                                                                                 <span style="font-family:Helvetica,arial,sans-serif;font-size:15px;display:inline-block;color:#4a4a4a;padding-top:2px">Adults - '.$adult.', Child - '.$child.'   </span>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                            
                            
                            
                            <tr>
                                <td style="padding:0 30px" width="100%">
                                    <table cellpadding="0" cellspacing="0" border="0" class="m_-3150665402647626555m_267825655353094048devicewidthinner" width="100%">
                                        <tbody><tr>
                                            <td width="100%" style="border-bottom:1px solid #d8d8d8;padding:15px 0">
                                                
                                                <table width="170" align="left" border="0" cellpadding="0" cellspacing="0" class="m_-3150665402647626555m_267825655353094048devicewidth">
                                                    <tbody>
                                                        <tr>
                                                            <td width="100%" align="left" class="m_-3150665402647626555m_267825655353094048devicewidth" style="padding:5px 0">
                                                                <table width="100%" cellspacing="0" cellpadding="0">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td width="30%">
                                                                               <span style="font-family:Helvetica,arial,sans-serif;font-weight:bold;font-size:15px;display:inline-block;color:#4a4a4a">Additional Information </span>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                     </tbody>
                                                </table>
                                                
                                                
                                                <table width="370" align="left" border="0" cellpadding="0" cellspacing="0" class="m_-3150665402647626555m_267825655353094048devicewidth">
                                                    <tbody>
                                                        <tr>
                                                            <td width="100%" align="left" class="m_-3150665402647626555m_267825655353094048devicewidth" style="padding-bottom:5px">
                                                                <table width="100%" cellspacing="0" cellpadding="0">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td>
                                                                    
                                                                    <p style="font-family:Helvetica,arial,sans-serif;font-size:15px;margin:0;padding-top:3px;padding-bottom:3px;color:#4a4a4a">Booking Policy: </p><br>
                                                                    
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                            
                            
                            <tr>
                                <td style="padding:0 30px" width="100%">
                                    <table cellpadding="0" cellspacing="0" border="0" class="m_-3150665402647626555m_267825655353094048devicewidthinner" width="100%">
                                        <tbody><tr>
                                            <td width="100%" style="border-bottom:1px solid #d8d8d8;padding:15px 0">
                                                
                                                <table width="170" align="left" border="0" cellpadding="0" cellspacing="0" class="m_-3150665402647626555m_267825655353094048devicewidth">
                                                    <tbody>
                                                        <tr>
                                                            <td width="100%" align="left" class="m_-3150665402647626555m_267825655353094048devicewidth" style="padding:5px 0">
                                                                <table width="100%" cellspacing="0" cellpadding="0">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td width="30%">
                                                                               <span style="font-family:Helvetica,arial,sans-serif;font-weight:bold;font-size:15px;display:inline-block;color:#4a4a4a">Cancellation Policy </span>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                     </tbody>
                                                </table>
                                                
                                                
                                                <table width="370" align="left" border="0" cellpadding="0" cellspacing="0" class="m_-3150665402647626555m_267825655353094048devicewidth">
                                                    <tbody>
                                                        <tr>
                                                            <td width="100%" align="left" class="m_-3150665402647626555m_267825655353094048devicewidth" style="padding-bottom:5px">
                                                                <table width="100%" cellspacing="0" cellpadding="0">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td>
                                                                    
                                                                    
                                                                    <p style="font-family:Helvetica,arial,sans-serif;font-size:15px;margin:0;padding-top:3px;padding-bottom:3px;color:#4a4a4a">Package cancellation will be as per our <strong>"terms of use"</strong> metioned on our website</p><br>
                                                                    
                                                                    <p style="font-family:Helvetica,arial,sans-serif;font-size:15px;margin:0;padding-top:3px;padding-bottom:3px;color:#4a4a4a">Travel Cash used in the booking will be Non-Refundable..</p><br>
                                                                    
                                                                    <p style="font-family:Helvetica,arial,sans-serif;font-size:15px;margin:0;padding-top:3px;padding-bottom:3px;color:#4a4a4a">Any Add On charges are non-refundable.</p><br>
                                                                    
                                                                    <p style="font-family:Helvetica,arial,sans-serif;font-size:15px;margin:0;padding-top:3px;padding-bottom:3px;color:#4a4a4a">You can not change the check-in or check-out date.</p><br>
                                                                    
                                                                    
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                            
                            <tr>
                                <td style="padding:0 30px" width="100%">
                                    <table cellpadding="0" cellspacing="0" width="100%" class="m_-3150665402647626555m_267825655353094048devicewidthinner">
                                        <tbody>
                                            <tr>
                                                <td width="100%" style="padding:20px 0">
                                                   <p style="font-family:Helvetica,arial,sans-serif;font-weight:bold;font-size:16px;color:#4a4a4a;font-weight:bold;line-height:25px;text-align:left;margin-top:15px;font-weight:bold;margin-bottom:0;display:inline-block;padding:0" class="m_-3150665402647626555m_267825655353094048emparaTxt">Need Help?</p>
													<p class="m_-3150665402647626555m_267825655353094048contentTxt" style="color:#4a4a4a;font-family:Helvetica,arial,sans-serif;font-size:15px;line-height:25px;margin-top:0;padding:0">
                                                          For any questions related to booking information, you can contact directly at: <a href="tel:%9990999561" style="text-decoration:underline!important" rel="noreferrer" target="_blank">9990999561</a>
                                                            or <a href="https://mail.google.com/mail/?view=cm&amp;tf=1&amp;support@goingbo.com" style="text-decoration:underline!important" rel="noreferrer" target="_blank">support@goingbo.com</a>
                                                    </p>
                                                     <p class="m_-3150665402647626555m_267825655353094048contentTxt" style="color:#4a4a4a;font-family:Helvetica,arial,sans-serif;font-size:15px;line-height:15px;margin-top:0;padding:0">
                                                        If you would like to change or upgrade your reservation, visit
                                                        <a href="https://goingbo.com" style="text-decoration:underline!important" rel="noreferrer" target="_blank" data-saferedirecturl="https://goingbo.com">goingbo.com</a></p>
                                                        <p class="m_-3150665402647626555m_267825655353094048contentTxt" style="color:#4a4a4a;font-family:Helvetica,arial,sans-serif;font-size:15px;line-height:15px;margin-top:0;padding:0">
                                                        <a href="https://goingbo.com" style="text-decoration:underline!important" rel="noreferrer" target="_blank" data-saferedirecturl="https://goingbo.com">Click here</a> to see booking policies.</p>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                    </tbody></table>
                </td>
            </tr>
        </tbody>
    </table>
    
    <table width="100%" bgcolor="#eaeaea" cellpadding="0" cellspacing="0" border="0" id="m_-3150665402647626555m_267825655353094048backgroundTable">
            <tbody>
                <tr>
                    <td>
                        <table width="630" bgcolor="#ffffff" cellpadding="0" cellspacing="0" border="0" align="center" class="m_-3150665402647626555m_267825655353094048devicewidth" style="margin:0 auto">
                            <tbody>
                                <tr>
                                    <td width="100%" style="padding:30px 0">
                                        <table bgcolor="#ffffff" cellpadding="0" cellspacing="0" border="0" align="center" class="m_-3150665402647626555m_267825655353094048devicewidthinner">
                                            <tbody>
                                                <tr>
                                                    <td style="padding-top:7px"><span style="float:left;font-weight:bold;font-family:Helvetica,arial,sans-serif;font-size:16px;color:#2962aa;margin-right:5px;display:inline-block"> goCare Support </span><span style="font-family:Helvetica,arial,sans-serif;font-weight:bold;font-size:16px;color:#5c5c5c;text-decoration:none;margin:0;display:inline-block">- It is FASTER to WRITE to US</span>
                                                        <span style="float:left;font-family:Helvetica,arial,sans-serif;font-size:15px;text-decoration:none;margin:0;padding-bottom:10px;width:100%;color:#5c5c5c">
                                                        Mail at support@goingbo.com to tell us your issue OR call us at <a href="tel:%9990999561" rel="noreferrer" target="_blank">9990999561</a></span>
                                                    </td>
                                                </tr>
					                        </tbody>
                                        </table>
                                    </td>
                                 </tr>
                          </tbody>
                     </table>
			    </td>
		    </tr>
      </tbody>
</table>


    <table width="100%" bgcolor="#eaeaea" cellpadding="0" cellspacing="0" border="0" id="m_-3150665402647626555m_267825655353094048backgroundTable_lpg">
        <tbody>
            <tr>
                <td>
                    <table width="630" bgcolor="#ffffff" cellpadding="0" cellspacing="0" border="0" align="center" class="m_-3150665402647626555m_267825655353094048devicewidth" style="margin:0 auto">
                        <tbody>
                            <tr>
                                <td width="100%" style="padding:0 30px">
                                    <table cellpadding="0" cellspacing="0" border="0" class="m_-3150665402647626555m_267825655353094048devicewidthinner" width="100%">
                                        <tbody><tr>
                                            <td width="100%" style="padding:0px 0">
                                            </td>
                                        </tr>
                                    </tbody></table>
                                </td>
                             </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
    <div class="yj6qo"></div><div class="adL">
    </div>
    </div>';
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: <info@goingbo.com>' . "\r\n";
$headers .= 'Cc: support@goingbo.com' . "\r\n";
if(mail($to,$subject,$message,$headers)){
  echo "Email has been sent successfully";  
  echo "<script type='text/javascript'> document.location = 'index.php'; </script>";
exit();
 }else{
    echo "Not Send";
}

?>


