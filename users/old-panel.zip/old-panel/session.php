<?php
session_start();
include("dbconnection.php");

$user_check = $_SESSION['enrolment'];
   
   $ses_sql = mysqli_query($db,"Select register from `login-book` where username = '$user_check' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   
   $login_session = $row['username'];
   
   if(!isset($_SESSION['login_user'])){
      header("location:login.php");
      die();
   }