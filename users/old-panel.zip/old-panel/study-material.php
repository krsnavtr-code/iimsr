<?php
include('header/head.php');
?>
<!DOCTYPE html >
<html xmlns="http://www.w3.org/1999/xhtml">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">	
	<title>VBIMT Institute</title>
	<link rel="stylesheet" type="text/css" href="css/csss.css" />	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script src="js/vbimtlandingpage.js"></script>
	
</head>
<body>
	<div class="container">
		<div id="top-bar">
			<a href="http://vbimt.org.in/"><img src="logo.png" alt="DZone" class="floatleft" /></a>
			
			   <div class="topmeenu" style="">
					<!--<a href="#" class="first">User Name</a>
					<a href="#">Submit New</a>
					<a href="logout.php">Logout</a>
					<a href="#"><button type="button" class="btn btn-Primary">User Name</button></a>
					<a href="#"><button type="button" class="btn btn-success">Submit New</button></a>-->
					<a href="logout.php"><button type="button" class="btn btn-danger">Logout</button></a>
				</div>
			 <div class="topm">
				<!--<form id="main-search"action="index.php " method="post">
					<label for="search-field" id="search-field-label">Search</label>
					<input type="text" tabindex="1" maxlength="255" id="search-field"/>
					<input type="image" alt="Search" value="Search" style="" src="images/search.png" id="search-button"/> --> 
				</form>
			</div>
		</div>
	<?php include('header/header.php'); ?>


<div id="feature-content">
				   <div class="">
				     <div id="feature">
				        <div style="overflow-x:auto; margin-bottom: 20px; height: 370px;">
							<h3>Study Material : <a href="#">Download Study Material Pdf</a> </h3>
							<h3>Study Material : <a href="#">Download Study Material Pdf</a></h3>
				        </div>
				    </div>
			    </div>
		    </div>








<?php include('footer/footer.php'); ?>
	
</body>

</html>
