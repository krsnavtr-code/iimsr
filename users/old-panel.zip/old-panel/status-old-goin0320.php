<?php
include('header/head.php');
?>

<!DOCTYPE html >
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8">
    <meta name="robots" content="Index, Follow" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">	
	<title>Status Vidya Bharati Institute Of Management & Technology</title>
	<link rel="stylesheet" type="text/css" href="css/csss.css" />	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script src="js/vbimtlandingpage.js"></script>
	
</head>
<body>
	<div class="container">
		<div class="row" id="top-bar">
		    <div class="col-sm-8 col-md-8 col-lg-8 col-xs-8" id="top-bar">
    			<a href="http://vbimt.org.in/"><img src="logo.png" alt="DZone" class="floatleft AdminPanelLogo" /></a>
    		</div>	
    		<div class="col-sm-4 col-md-4 col-lg-4 col-xs-4">
                <div class="topmeenu" style="">
                    <a href="logout.php"><button type="button" class="btn btn-danger AdminLogoutBu">Logout</button></a>
            	</div>
                <div class="topm"></div>
		    </div>
		</div>
		<?php include('header/header.php'); ?>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xs-12">
        		<h4 class="StudentStatus">Student Status</h4>			  
        		  <div style="overflow-x:auto; margin-bottom: 50px;">
        			<table class="table table-hover no-more-tables">
            			<tr>
            			    <th style="min-width: 110px;">Enrolment No</th>
            				<th style="min-width: 250px;">Course</th>
            				<th style="min-width: 150px;">Branch</th>
            				<th style="min-width: 150px;">Semester/Year</th>
            				<th style="color:#ff0000;min-width: 110px;">Lateral Entry</th>
            				<th style="min-width: 200px;">Full Name</th>
            				<th style="min-width: 200px;">Mother Name</th>
            				<th style="min-width: 200px;">Father Name</th>
            				<th style="min-width: 150px;">Email</th>
            				<th style="min-width: 110px;">Mobile No</th>
            				<th style="min-width: 300px;">Address</th>
            				<th style="min-width: 110px;">Date Of Birth</th>
            				<th style="min-width: 110px;">Submit Fee</th>
            				<th style="min-width: 110px;color:#ff0000;">Due Fee</th>
            				<th style="min-width: 110px;">Total Fee</th> 
            			</tr>
            			
            	          <?php
            			    $enrol = $_SESSION['enrolment'];
            			    $query = mysqli_query($con, "SELECT * FROM `register_here` where `enrolment` = '$enrol'");
            			    while($row = mysqli_fetch_array($query))
            			  {?>	
                        <tr>
                            <td><b><?php echo $row['enrolment'];?></b></td>
                            <td><?php echo $row['course'];?></td>
                            <td><?php echo $row['specilization'];?></td>
                            <td><center><?php echo $row['semesters'];?></center></td>
                            <td style="color:#ff0000;"><?php echo $row['lateral_entry'];?></td>
                            <td><?php echo $row['name'];?></td>
                            <td><?php echo $row['mothers_name'];?></td> 
                            <td><?php echo $row['fathers_name'];?></td>
                            <td><?php echo $row['email'];?></td>
                            <td><?php echo $row['mobile_no'];?></td>
                            <td><?php echo $row['complete_add'];?></td>
                            <td><?php echo $row['dob'];?></td>
                            <td><?php echo $row['submit_fee'];?></td>
                            <td style="color:#ff0000;"><?php echo $row['deu_fee'];?></td>	
                            <td><?php echo $row['total_fee'];?></td>			 	  
                        </tr>
            		    <?php } ?>
                   </table>
        		</div>
    		</div>
		</div><br><br><br><br><br><br>
        <?php include('footer/footer.php'); ?>	
	 </div>
</body>
   <style>
       .StudentStatus{
           font-weight:bold;
            font-size:13px;
            text-align:justify;
       }
       .Kindlydeposit{
            color:red; 
            font-weight:bold;
            font-size:13px;
            text-align:justify;
        }
       .floatleft.AdminPanelLogo {
            width: 200px;
            height: auto;
        }
        .AdminLogoutBu {
            border-radius: 0px !important;
            padding: 7px 13px 7px 13px !important;
        }
    @media(max-width:992px){
        .Kindlydeposit{
            color:red !important;
            font-weight:bold !important;
            font-size:10px !important;
        }
    }
   </style>
</html>
