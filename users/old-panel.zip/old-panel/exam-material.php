<?php
include('header/head.php');
?>

<!DOCTYPE html >
<html xmlns="http://www.w3.org/1999/xhtml">

<head>	
    <title>VBIMT Institute</title>
    <link rel="stylesheet" type="text/css" href="css/csss.css" />	
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script src="js/vbimtlandingpage.js"></script>
	
</head>
<body>
	<div class="container">
		<div class="row" id="top-bar">
		    <div class="col-sm-7 col-md-7 col-lg-7 col-xs-8" id="top-bar">
    			<a href="http://vbimt.org.in/"><img src="logo.png" alt="DZone" class="floatleft AdminPanelLogo" /></a>
    		</div>	
    		<div class="col-sm-4 col-md-4 col-lg-4 col-xs-4">
                <div class="topmeenu" style="">
                    <a href="logout.php"><button type="button" class="btn btn-danger AdminLogoutBu">Logout</button></a>
            	</div>
                <div class="topm"></div>
		    </div>
		</div>
		<?php include('header/header.php'); ?>
              <div id="feature-content">
				   <div class="">
				     <div id="feature">
				        <div style="overflow-x:auto; margin-bottom: 20px; height: 370px;">
							<h3>Exam Material : <a href="#">Download Exam Material Pdf</a> </h3>
							<h3>Exam Material : <a href="#">Download Exam Material Pdf</a></h3>
				        </div>
				    </div>
			    </div>
		    </div>
 <?php include('footer/footer.php'); ?>
	
</body>

</html>
