<?php 
include('session.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Booking Form HTML Template</title>
    <!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
    <!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />
    <!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />
	<style>
	    body{
	        background:rgba(47, 103, 177, 0.6);
	    }
	</style>
</head>

<body>
    <div id="booking" class="section">
        <div class="section-center">
			<div class="container">
			    <div class="row">
			        <div class="col-sm-12">
			            
     <div align="right" style="padding-top:30px"><button class="btn btn-default"><a href = "logout.php">Sign Out</a></button></div>
			        </div>
			    </div>
			    <div class="row">
					<div class="col-md-5 col-xs-12 col-ms-5">
						<div class="booking-cta">
							<h2 style="color:#fff">Create Invoice</h2>
							<p>Please Fill Form very Carefully
							</p>
						</div>
					</div>
					<div class="col-md-7 col-ms-7 col-xs-12">
					    <div style="margin-top:30px">
						<div class="booking-form">
							<form name="confim" action="invice-mail.php" method="post">
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
										<input class="form-control" type="text" name="source" placeholder="From">
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
										<input class="form-control" type="text" name="destination" placeholder="To">
										</div>
									</div>
								</div>
								<div class="row">
								    
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
										    <input class="form-control" type="text" name="bookingid" placeholder="Booking Id">
										</div>
									</div>
									
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
										<input class="form-control" type="text" name="adultname" placeholder="Name">
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
										<input class="form-control" type="text" name="mail" placeholder="Email id">
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
										<input class="form-control" type="text" name="phone" placeholder="Phone Number">
										</div>
									</div>
								</div>
								
								<div class="row">
								    <div class="col-sm-6 col-xs-12">
										<div class="form-group">
									   <input class="form-control" type="date" name="departdate" placeholder="Departure Date" required>
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
										<input class="form-control" type="text" name="totalamount" placeholder="Total Amount">
										</div>
								    </div>
								</div>
								
								<div class="row">
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<input class="form-control" type="text" name="amount" placeholder="Received Amount">
										</div>
									</div>
									<div class="col-sm-6 col-xs-12">
										<div class="form-group">
											<input class="form-control" type="text" name="pendingamount" placeholder="Pending Amount">
										</div>
									</div>
								</div>
								
								<div class="form-btn">
								     <input type="submit" name="Submit" value="Book" class="submit-btn">
								</div>
							</form>
						</div>
						<div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>